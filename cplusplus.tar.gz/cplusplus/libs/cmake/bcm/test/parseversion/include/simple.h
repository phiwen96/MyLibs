
#ifndef GUARD_SIMPLE_H
#define GUARD_SIMPLE_H

#include <version.h>

inline void simple()
{
}


#endif
