
int main() {
    try {
        throw "up";
    } catch(...) {
    }
}
