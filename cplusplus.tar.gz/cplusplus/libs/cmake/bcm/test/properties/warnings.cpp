
struct A;  
class A {};   // C4099

int main() {
    // Unused variable
    int i = 0;
}
