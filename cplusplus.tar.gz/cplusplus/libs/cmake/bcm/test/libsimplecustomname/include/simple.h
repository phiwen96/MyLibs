
#ifndef GUARD_SIMPLE_H
#define GUARD_SIMPLE_H

inline void simple()
{
}


#endif
