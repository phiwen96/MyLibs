
#include <simple.h>
#include <cstdlib>

int main()
{
    return 1;
}
