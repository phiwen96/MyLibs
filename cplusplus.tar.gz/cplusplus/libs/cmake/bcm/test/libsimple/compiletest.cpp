#include <simple.h>
#include <cstdlib>

int main()
{
    std::abort();
    simple();   
}