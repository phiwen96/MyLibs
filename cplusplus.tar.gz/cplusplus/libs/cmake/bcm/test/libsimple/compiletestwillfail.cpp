#include <simple.h>
#include <cstdlib>

int main()
{
    static_assert(false, "Error") ;
}