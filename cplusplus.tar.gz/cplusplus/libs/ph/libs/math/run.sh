#!/bin/bash
CURRENT=`pwd`
lib=`basename "$CURRENT"`

echo "$lib"

cd .. && cd .. && cd .. && cd .. 

cd build && cmake .. . && make && echo "" && echo "--------------" && echo "" && libs/ph/libs/"$lib"/ph_"$lib"_test