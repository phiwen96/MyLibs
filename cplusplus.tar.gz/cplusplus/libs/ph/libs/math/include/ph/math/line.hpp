#pragma once
#include <ph/math/point.hpp>
#include <ph/math/definitions.h>
#include <math.h>
#include <ph/math/math.hpp>
#include <ph/math/vector.hpp>

namespace ph::math
{

/**
 TODO
 
 check if 2 lines intersects
 
 construera från två punkter
 
 */


class line
{
      
};






}
