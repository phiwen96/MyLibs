// #pragma once



// namespace ph::math
// {


// struct Testing 
// {
//       virtual void run ();
      
// private:
//       void test_point ();
//       void test_vector ();
//       void test_line ();
//       void test_plane ();
//       void test_matrix ();
    
// };







// }
