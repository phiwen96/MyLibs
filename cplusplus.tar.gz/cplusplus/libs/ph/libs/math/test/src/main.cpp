#include <test/main.hpp>
#include <ph/math/math.hpp>
#include <ph/math/point.hpp>
#include <ph/math/test.hpp>
#include <ph/math/point.hpp>
#include <ph/math/vector.hpp>
#include <ph/math/plane.hpp>
#include <ph/math/line.hpp>
#include <ph/math/matrix.hpp>
#include <iostream>
using namespace std;

using namespace ph::math;



int main(int argc, char** argv)
{
       
      Matrix<2, 3, int> m1({1, 2, 3}, {1, 7, 3});
      Matrix<3, 2, int> m1_transposed = m1;
      cout << m1 << endl;
      
     // Testing t;
      //t.run();
      
     

    return 0;
}
