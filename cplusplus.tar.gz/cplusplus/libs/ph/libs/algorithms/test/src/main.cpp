#include <test/main.hpp>
#include <ph/algorithms/algorithms.hpp>
#include <ph/algorithms/test.hpp>
#include <ph/data_structures/data_structures.hpp>
using namespace ph::algorithms;

int main(int argc, char** argv)
{
      
      Testing t;
      t.run();
      
      
      
      // constexpr auto s2 = Size<int, char>::value;
    return 0;
}
