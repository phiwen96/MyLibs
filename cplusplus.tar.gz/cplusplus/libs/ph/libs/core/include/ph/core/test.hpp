#pragma once
#include <ph/testing/testing.hpp>
#include <ph/core/core.hpp>



namespace ph::core
{


struct Testing : ph::testing::Testing
{
      virtual void run () override
      {
            
      }
      
     

      
};







}
