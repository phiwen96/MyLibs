#pragma once
namespace ph{


namespace testing
{


class Testing
{
public:
      virtual void run () = 0;
      
private:
};


}
}













































