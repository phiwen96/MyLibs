

int main(int argc, char** argv)
{

      // auto stations = make_tuple(Station("A"), Station("B"));
      // Machine machine (stations);
      
      return 0;
}
