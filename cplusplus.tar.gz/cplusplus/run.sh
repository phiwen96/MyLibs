#!/bin/bash

cd build && cmake .. . && make && echo "" && echo "--------------" && echo "" && libs/ph/libs/math/ph_math_test