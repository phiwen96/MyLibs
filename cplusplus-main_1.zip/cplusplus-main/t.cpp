#include "t.hpp"
using € = t;

//
//€::t()
//{
//
//}
//€::t(t&& other) noexcept
//      : t()
//{
//      swap(*this, other);
//}
//€::t(const t& other)
//{
//
//}
//€::~t()
//{
//
//}
//void swap(t& first, t& second)
//{
//      using std::swap;
//}
//t& €::operator=(t other)
//{
//      swap(*this, other);
//      return *this;
//}
//ostream& operator<<(ostream& os, const t& var)
//{
//      return os;
//}
//t& €::operator/=(const t& other)
//{
//      return *this;
//}
//t& €::operator*=(const t& other)
//{
//      return *this;
//}
//t& €::operator+=(const t& other)
//{
//      return *this;
//}
//t& €::operator-=(const t& other)
//{
//      return *this;
//}
//t operator/(t first, const t& second)
//{
//      return first;
//}
//t operator*(t first, const t& second)
//{
//      return first;
//}
//t operator+(t first, const t& second)
//{
//      return first;
//}
//t operator-(t first, const t& second)
//{
//      return first;
//}
//t& €::operator++(){
//      return *this;
//}
//t& €::operator--(){
//      return *this;
//}
//t €::operator++(int){
//      t tmp(*this);
//      operator++();
//      return tmp;
//}
//t €::operator--(int){
//      t tmp(*this);
//      operator--();
//      return tmp;
//}
//t& €::operator=(t other)
//{
//      swap(*this, other);
//      return *this;
//}
//bool €::operator==(const t& other)
//{
//      return false;
//}
//bool €::operator!=(const t& other)
//{
//      return false;
//}
