#include "xcards/xcards.hpp"
// #include <ph/time/date/Date.hpp>
// #include <ph/time/timer/Timer.hpp>

int main(int argc, char** argv)
{
      // ph::time::Timer t("hej");
      // ph::time::Date d;
      // xcards app2 (argc, argv);
      
      
      
      // return app2.exec();
}
