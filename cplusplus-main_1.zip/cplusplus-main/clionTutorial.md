# Tutorial

* unfold/fold  
  * ctr + numpad + or -
  
* move everything below down
    * Ctr + Enter
    
* Show ocurrences 
    * Alt + F7
    
* jump to definition
    * Alt + B
    * Choose implementation
    
        * Ctr + Shift + B 
       
    
* Go to previous line
    * Ctr + Alt + right arrow / left arrow
    
* Navigate 
    * To file
        - Ctr + Shift + N
     
    * To class
        - Ctr + N
        
    * To symbol
        - Ctr + Alt + Shift + N
        
    * To next method
        - Alt + down / up
        
        
* Scroll 
    * Ctr + down / up / left / right
    