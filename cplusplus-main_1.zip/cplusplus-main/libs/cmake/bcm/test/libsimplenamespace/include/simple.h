
#ifndef GUARD_SIMPLE_H
#define GUARD_SIMPLE_H

#ifndef HAS_SIMPLE
#error "Not configured"
#endif

inline void simple()
{
}


#endif
