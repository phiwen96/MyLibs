
#include <simpleversion.hpp>
#include <simple.h>

int main()
{
    simple();   
}
