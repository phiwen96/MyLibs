
#include <simple.h>

int main()
{
    simple();   
}
