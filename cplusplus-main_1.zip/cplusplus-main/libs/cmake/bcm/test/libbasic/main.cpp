
#include <simpleversion.hpp>
#include <simple.h>

inline void basic()
{
    simple();   
}
