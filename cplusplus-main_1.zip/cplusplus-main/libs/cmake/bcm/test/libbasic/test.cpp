
int main() {}
