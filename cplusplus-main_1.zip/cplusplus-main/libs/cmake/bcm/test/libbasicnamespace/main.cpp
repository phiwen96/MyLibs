
#include <simple.h>

inline void basic()
{
    simple();   
}
