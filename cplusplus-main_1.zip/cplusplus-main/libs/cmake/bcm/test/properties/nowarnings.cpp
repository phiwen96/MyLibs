
int main() {
    // Unused variable
    int i = 0;
    (void)i;
}
