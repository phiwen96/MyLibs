//
//  point.cpp
//  ph_math
//
//  Created by philip wenkel on 2020-11-03.
//

#include <stdio.h>
