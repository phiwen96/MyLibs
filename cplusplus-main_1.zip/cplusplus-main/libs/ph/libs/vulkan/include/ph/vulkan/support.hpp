#pragma once
#include "../../../src/support.cpp"

namespace ph::vulkan{


    class A{


          [[maybe_unused]] int b(){}
      };
      
      
      
}
