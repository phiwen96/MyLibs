#include <test/main.hpp>
#include <ph/data_structures/data_structures.hpp>
#include <ph/data_structures/test.hpp>
 using namespace ph::data_structures;

int main(int argc, char** argv)
{
       
       Testing t;
       t.run();
      
      
      
      // constexpr auto s2 = Size<int, char>::value;
    return 0;
}
