kuk# ph
root dir for all Philip's C++ librarymkmnjnjvcphph