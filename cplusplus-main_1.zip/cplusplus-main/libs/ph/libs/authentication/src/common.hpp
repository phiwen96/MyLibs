#pragma once
namespace ph::authentication{
template <typename T>
struct Type{};
}
