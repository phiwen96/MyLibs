//
//  T.hpp
//  Timer
//
//  Created by philip wenkel on 2020-10-29.
//

#ifndef T_h
#define T_h
struct T{
      
};

#endif /* T_h */
