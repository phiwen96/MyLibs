#pragma once 


struct pu
{
    pu(int i);
    /* data */
    int i;
};
