#pragma once
namespace ph::testing
{


class Testing
{
public:
      virtual void run () = 0;
      
private:
};


}













































