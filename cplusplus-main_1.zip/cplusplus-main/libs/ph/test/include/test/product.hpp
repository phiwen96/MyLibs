// #pragma once

// class Pill;


// class Product
// {
// public:
      
// private:
//       Pill* m_pill;
      
// };
