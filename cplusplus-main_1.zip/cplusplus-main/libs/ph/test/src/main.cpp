// #include <test/main.hpp>
// #include <test/machine.hpp>
// #include <test/product.hpp>
// #include <test/pill.hpp>
// #include <test/station.hpp>



int main(int argc, char** argv)
{

      // auto stations = make_tuple(Station("A"), Station("B"));
      // Machine machine (stations);
      
      return 0;
}
