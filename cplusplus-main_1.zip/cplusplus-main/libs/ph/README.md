# ph
root dir for all Philip's C++ library
